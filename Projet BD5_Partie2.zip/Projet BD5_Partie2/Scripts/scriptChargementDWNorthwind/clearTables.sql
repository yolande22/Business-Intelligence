--1b) Clear all tables data warehouse tables and reset their Identity Auto Number 
Use DWNorthwind
go

Truncate Table [dbo].[FactSales];

Truncate table [dbo].[DimProducts];

Truncate table [dbo].[DimCategories];

Truncate table [dbo].[DimCustomers];

Truncate table [dbo].[DimEmployees];

Truncate table [dbo].[DimAddress];

Truncate table [dbo].[DimShippers];

Truncate table [dbo].[DimDates]
Go