Use DWNorthwind
go

-- 1a) Drop Foreign Keys 

Alter Table [dbo].[DimProducts] drop Constraint [FK_DimProducts_DimCategories] 


Alter Table [dbo].[DimEmployees] drop Constraint [FK_DimEmployees_DimAddress] 


Alter Table [dbo].[DimCustomers]drop Constraint [FK_DimCustomers_DimAddress] 


Alter Table [dbo].[FactSales] drop Constraint [FK_FactSales_DimProducts] 


Alter Table [dbo].[FactSales] drop Constraint [FK_FactSales_DimCustomers] 


Alter Table [dbo].[FactSales] drop Constraint [FK_FactSales_DimEmployees] 


Alter Table [dbo].[FactSales]  drop Constraint [FK_FactSales_DimDates] 


Alter Table [dbo].[FactSales]  drop Constraint [FK_FactSales_DimAddress] 


Alter Table [dbo].[FactSales]  drop Constraint [FK_FactSales_DimShippers] 

-- You will add Foreign Keys back (At the End of the ETL Process)
Go