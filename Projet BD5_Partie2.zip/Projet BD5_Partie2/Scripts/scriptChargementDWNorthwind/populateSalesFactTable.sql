Use DWNorthwind
go




--2h)Get source data from [northwind].[dbo].[OrdersDetails] and
insert into [FactSales]
Select

 [OrderNum] = [northwind].[dbo].[Orders].[OrderID],
	[OrderDateKey] =[DimDates].[DateKey],
	[CustomerKey] = [DimCustomers].[CustomerKey],
	[ProductKey] = [DimProducts].[ProductKey],
	[EmployeeKey] =[DimEmployees].[EmployeeKey],
	[ShippedAddressKey]=[DimAddress].[AddressKey],
	[RequiredDateKey]=D.[DateKey],
	[ShippedDateKey]=T.[DateKey],
	[ShipViaKey]=[DimShippers].[ShipperKey],
	[ShipName]=[northwind].[dbo].[Orders].[ShipName],
	[Freight]=[northwind].[dbo].[Orders].[Freight],
	[SalesQuantity] = [northwind].[dbo].[Order Details].[Quantity],
	[UnitPrice] = [northwind].[dbo].[Order Details].[UnitPrice],
	[Discount] = [northwind].[dbo].[Order Details].[Discount]

   
  
From [northwind].[dbo].[Order Details] 
JOIN [northwind].[dbo].[Orders] 
ON  [northwind].[dbo].[Order Details].[OrderID] = [northwind].[dbo].[Orders].[OrderID] 

JOIN [DWNorthwind].[dbo].[DimDates]
  On [northwind].[dbo].[Orders].[orderDate] = [DWNorthwind].[dbo].[DimDates].[date]

  JOIN [DWNorthwind].[dbo].[DimDates] as D
  On [northwind].[dbo].[Orders].[RequiredDate] = D.[date]

JOIN [DWNorthwind].[dbo].[DimDates] as T
  On [northwind].[dbo].[Orders].[ShippedDate] = T.[date]


JOIN  [DWNorthwind].[dbo].[DimCustomers]
  On [northwind].[dbo].[Orders].[CustomerID] = [DWNorthwind].[dbo].[DimCustomers].[CustomerID]

JOIN  [DWNorthwind].[dbo].[DimProducts]
  On [northwind].[dbo].[Order Details].[ProductID]  = [DWNorthwind].[dbo].[DimProducts].[ProductId]

JOIN  [DWNorthwind].[dbo].[DimEmployees]
  On [northwind].[dbo].[Orders].[EmployeeID] = [DWNorthwind].[dbo].[DimEmployees].[EmployeeID]

 JOIN [DWNorthwind].[dbo].[DimAddress]
  On [northwind].[dbo].[Orders].[ShipAddress] = [DWNorthwind].[dbo].[DimAddress].[Address]

  JOIN [DWNorthwind].[dbo].[DimShippers]
  On [northwind].[dbo].[Orders].[ShipVia] = [DWNorthwind].[dbo].[DimShippers].[ShipperID]
GO
GO
