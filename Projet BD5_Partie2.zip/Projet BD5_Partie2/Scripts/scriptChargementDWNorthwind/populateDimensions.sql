Use DWNorthwind
go

-- Step 2) Code used to fill tables (Will be used with SSIS Data Flow Tasks)

-- 2a) Get source data from [northwind].[dbo].[Customers] and



insert into DimCustomers
Select 
	[CustomerId] = [CustomerId],
	[CustomerAddressKey]=[DWNorthwind].[dbo].[DimAddress].AddressKey,
	[CompanyName] =[CompanyName],
	[ContactName] = [ContactName],
	[ContactTitle] = [ContactTitle],
	[Phone] = cast(isNull ([Phone], 'UnKnown') as [nvarchar](24))

From [northwind].[dbo].[Customers] join [DWNorthwind].[dbo].[DimAddress] 
on [DWNorthwind].[dbo].[DimAddress].Address=[northwind].[dbo].[Customers].Address
Go


-- 2b) Get source data from [northwind].[dbo].[Categories] and
insert into [DimCategories]
Select 
  
	[CategoryId]= [CategoryId] ,
	[CategoryName] = [CategoryName],
	[Description] = [Description]
	
From [northwind].[dbo].[Categories]
Go




use DWNorthwind
go
-- 2c) Get source data from [northwind].[dbo].[Products] and


insert into DimProducts
Select 
    [ProductId] = [ProductId],
	[ProductName] = [ProductName],
	[CategoryKey] = [DWNorthwind].[dbo].[DimCategories].[CategoryKey],
	[QuantityPerUnit] = [QuantityPerUnit],
	[UnitPrice]  = [UnitPrice],
	[UnitInStock] = [UnitsInStock]
From [northwind].[dbo].[Products]
join [DWNorthwind].[dbo].[DimCategories]
on [northwind].[dbo].[Products].[CategoryID]=[DWNorthwind].[dbo].[DimCategories].[CategoryID]
Go




-- 2f) Get source data from [northwind].[dbo].[Employees] and
 insert into [DimEmployees]
Select
    [EmployeeID] =[EmployeeID],
	[EmployeeAddressKey]=[DWNorthwind].[dbo].[DimAddress].AddressKey,
	[LastName] =[LastName],
	[FirstName] =[FirstName],
	[Title] = [Title],
	[TitleOfCourtesy] = [TitleOfCourtesy],
	[BirthDate] = [BirthDate] ,
	[HireDate] =[HireDate],
	[HomePhone]=[HomePhone],
	[Extension]=[Extension],
	[ReportTo]=cast(isNull([ReportsTo], -1) as int)
	

From [northwind].[dbo].[Employees]join [DWNorthwind].[dbo].[DimAddress] 
on [DWNorthwind].[dbo].[DimAddress].Address=[northwind].[dbo].[Employees].Address
Go

--2g)Add additional lookup values to DimEmployee

Set Identity_Insert [DWNorthwind].[dbo].[DimEmployees] On

Insert into [DWNorthwind].[dbo].[DimEmployees]
(
    [EmployeeKey],
	[EmployeeID] ,
	[EmployeeAddressKey],
	[LastName],
	[FirstName] ,
	[Title],
	[TitleOfCourtesy] ,
	[BirthDate]  ,
	[HireDate] ,
	[HomePhone] ,
	[Extension] ,
	[ReportTo]
)
Select
    [EmployeeKey]= cast(-1 as int), 
	[EmployeeID] = -1 ,
	[EmployeeAddressKey]= -1,
	[LastName] = cast('Not found' as [nvarchar](20)),
	[FirstName] = cast('Not found' as [nvarchar](10) ),
	[Title]=cast('Not found' as [nvarchar](30) ),
	[TitleOfCourtesy]=cast('Not found' as [nvarchar](25) ),
	[BirthDate] = Cast('01/01/1900' as nVarchar(50) ),
	[HireDate] =Cast('01/01/1900' as nVarchar(50) ),
	[HomePhone]=cast('Not found' as [nvarchar](24) ),
	[Extension] = cast('Not found' as[nvarchar](4) ),
	[ReportTo] = -1

GO

Set Identity_Insert [DWNorthwind].[dbo].[DimEmployees] OFF


insert into [DimShippers]
Select 
  
	[ShipperId]=[ShipperId],
	[CompanyName] =[CompanyName],
	[Phone]= [phone]
	
From [northwind].[dbo].[Shippers]
Go






