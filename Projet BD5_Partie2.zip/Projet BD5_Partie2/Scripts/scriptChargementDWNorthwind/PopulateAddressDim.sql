use DWNorthwind
go

insert into dbo.DimAddress
Select distinct
   	[Address] = [shipAddress],
	[City] = [shipCity],
	[Region] = cast(isNull ([shipRegion], 'UnKnown') as [nvarchar](15)),
	[PostalCode] = cast(isNull ([shipPostalCode], 'UnKnown') as [nvarchar](10)),
	[Country] = [shipCountry]	

From [northwind].[dbo].[Orders]

 MERGE [DWNorthwind].[dbo].[DimAddress] AS [Target]
 USING [northwind].[dbo].[Customers] AS [Source]
 ON Target.Address = Source.Address
        WHEN MATCHED AND 
		(
					  Target.City <> Source.City
                      or Target.Region <> Source.Region
                      or Target.PostalCode <> Source.PostalCode
                      or Target.Country <> Source.Country
					 
		)
            THEN UPDATE  SET  
			   
						Target.City = Source.City
                      , Target.Region = cast(isNull (Source.Region, 'UnKnown') as [nvarchar](15))
                      , Target.PostalCode = cast(isNull (Source.PostalCode, 'UnKnown') as [nvarchar](10))
                      , Target.Country = Source.Country
					  
		    WHEN NOT MATCHED BY TARGET
            THEN INSERT (
						   Address,
	                       City,
	                       Region,
						   PostalCode,
						   Country						  
                        )
                VALUES  (Source.Address
						,Source.City
                      , cast(isNull (Source.Region, 'UnKnown') as [nvarchar](15))
                      , cast(isNull (Source.PostalCode, 'UnKnown') as [nvarchar](10))
                      , Source.Country);
				
 MERGE [DWNorthwind].[dbo].[DimAddress] AS [Target]
 USING [northwind].[dbo].[Employees] AS [Source]
 ON Target.Address = Source.Address
        WHEN MATCHED AND 
		(
					  Target.City <> Source.City
                      or Target.Region <> Source.Region
                      or Target.PostalCode <> Source.PostalCode
                      or Target.Country <> Source.Country
					 
		)
            THEN UPDATE  SET  
			   
						Target.City = Source.City
                      , Target.Region = cast(isNull (Source.Region, 'UnKnown') as [nvarchar](15))
                      , Target.PostalCode = cast(isNull (Source.PostalCode, 'UnKnown') as [nvarchar](10))
                      , Target.Country = Source.Country
					  
		    WHEN NOT MATCHED BY TARGET
            THEN INSERT (
						   Address,
	                       City,
	                       Region,
						   PostalCode,
						   Country						  
                        )
                VALUES  (Source.Address
						,Source.City
                      , cast(isNull (Source.Region, 'UnKnown') as [nvarchar](15))
                      , cast(isNull (Source.PostalCode, 'UnKnown') as [nvarchar](10))
                      , Source.Country);

Set Identity_Insert [DWNorthwind].[dbo].[DimAddress] On

Insert into [DWNorthwind].[dbo].[DimAddress]
(   
    [AddressKey],
    [Address] ,
 [City] ,
 [Region],
 [PostalCode],
 [Country] 
)
Select
    [AddressKey]= -1,
    [Address] =cast('Not found' as [nvarchar](60) ),
 [City] =cast('Not found' as[nvarchar](15) ),
 [Region]=cast('Not found' as [nvarchar](15) ),
 [PostalCode] =cast('Not found' as [nvarchar](10) ),
 [Country] =cast('Not found' as [nvarchar](15) )

GO

Set Identity_Insert [DWNorthwind].[dbo].[DimAddress] OFF
