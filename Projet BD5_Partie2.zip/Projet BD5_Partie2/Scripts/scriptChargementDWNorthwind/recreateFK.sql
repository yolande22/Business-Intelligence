use DWNorthwind
GO

/****** Add Foreign Keys ******/


Alter Table [dbo].[DimProducts] With Check Add Constraint [FK_DimProducts_DimCategories] 
Foreign Key   ([CategoryKey]) References [dbo].[DimCategories] ([CategoryKey])
go


Alter Table [dbo].[DimEmployees] With Check Add Constraint [FK_DimEmployees_DimAddress] 
Foreign Key   ([EmployeeAddressKey]) References [dbo].[DimAddress] ([AddressKey])
go

Alter Table [dbo].[DimCustomers] With Check Add Constraint [FK_DimCustomers_DimAddress] 
Foreign Key   ([CustomerAddressKey]) References [dbo].[DimAddress] ([AddressKey])
go


Alter Table [dbo].[FactSales] With Check Add Constraint [FK_FactSales_DimProducts] 
Foreign Key ([ProductKey]) References [dbo].[DimProducts] ([ProductKey])
Go

Alter Table [dbo].[FactSales] With Check Add Constraint [FK_FactSales_DimCustomers] 
Foreign Key ([CustomerKey]) References [dbo].[DimCustomers] ([Customerkey])
Go

Alter Table [dbo].[FactSales] With Check Add Constraint [FK_FactSales_DimEmployees] 
Foreign Key ([EmployeeKey]) References [dbo].[DimEmployees] ([EmployeeKey])
Go


Alter Table [dbo].[FactSales]  With Check Add Constraint [FK_FactSales_DimDates] 
Foreign Key ([OrderDateKey]) References [dbo].[DimDates]	(	[DateKey]	) 
Go

Alter Table [dbo].[FactSales]  With Check Add Constraint [FK_FactSales_DimAddress] 
Foreign Key ([ShippedAddressKey]) References [dbo].[DimAddress]	(	[AddressKey]	) 
Go

Alter Table [dbo].[FactSales]  With Check Add Constraint [FK_FactSales_DimShippers] 
Foreign Key ([ShipviaKey]) References [dbo].[DimShippers]	(	[ShipperKey]	) 
Go
