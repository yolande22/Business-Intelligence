USE [master]
GO

IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'DWNorthwind')
  BEGIN
     -- Close connections to the DWPubsSales database 
    ALTER DATABASE [DWNorthwind] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
    DROP DATABASE [DWNorthwind]
  END
GO

CREATE DATABASE [DWNorthwind] ON  PRIMARY 
( NAME = N'DWNorthwind'
, FILENAME = N'C:\temp\DWNorthwind.mdf' )
 LOG ON 
( NAME = N'DWNorthwind_log'
, FILENAME = N'C:\temp\DWNorthwind_log.LDF' )
GO