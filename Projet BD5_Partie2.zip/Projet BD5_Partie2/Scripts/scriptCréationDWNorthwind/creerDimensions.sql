USE [DWNorthwind]
GO
/****** Create the Dimension Tables ******/
CREATE TABLE [dbo].[DimCustomers](
	[CustomerKey] [int] NOT NULL PRIMARY KEY Identity,
	[CustomerId] [nchar](5) NOT NULL,
	[CustomerAddressKey] [int] NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[ContactName] [nvarchar](30) NOT NULL,
	[ContactTitle] [nvarchar](30) NOT NULL,
	[Phone] [nvarchar](24) NOT NULL
		
)
GO

CREATE TABLE [dbo].[DimCategories](
	[CategoryKey] [int] NOT NULL PRIMARY KEY Identity,
	[CategoryId] [int] NOT NULL,
	[CategoryName] [nvarchar](15) NOT NULL,
	[Description] [ntext] NOT NULL
	
)
GO


CREATE TABLE [dbo].[DimProducts](
	[ProductKey] [int] NOT NULL PRIMARY KEY Identity,
	[ProductId] [int] NOT NULL,
	[ProductName] [nvarchar](40) NOT NULL,
	[CategoryKey] [int] NOT NULL,
	[QuantityPerUnit] [nvarchar](20) NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitInStock] [smallint] NOT NULL
	
) 
GO


CREATE TABLE [dbo].[DimEmployees](
	[EmployeeKey] [int] NOT NULL PRIMARY KEY Identity,
	[EmployeeID] [int] NOT NULL,
	[EmployeeAddressKey] [int] NOT NULL,
	[LastName] [nvarchar](20) NOT NULL,
	[FirstName] [nvarchar](10) NOT NULL,
	[Title] [nvarchar](30) NOT NULL,
	[TitleOfCourtesy] [nvarchar](25) NOT NULL,
	[BirthDate] [datetime] NOT NULL,
	[HireDate] [datetime] NOT NULL,
	[HomePhone] [nvarchar](24) NOT NULL,
	[Extension] [nvarchar](4) NOT NULL,
	[ReportTo][int] NOT NULL
	
)
GO

CREATE TABLE [dbo].[DimAddress](
	[AddressKey] [int] NOT NULL PRIMARY KEY Identity,
	[Address] [nvarchar](60) NOT NULL,
	[City] [nvarchar](15) NOT NULL,
	[Region] [nvarchar](15) NOT NULL,
	[PostalCode] [nvarchar](10) NOT NULL,
	[Country] [nvarchar](15) NOT NULL,
	
		
)
GO

CREATE TABLE [dbo].[DimShippers](
	[ShipperKey] [int] NOT NULL PRIMARY KEY Identity,
	[ShipperId] [int] NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[Phone] [nvarchar](24) NOT NULL
	
)
GO
