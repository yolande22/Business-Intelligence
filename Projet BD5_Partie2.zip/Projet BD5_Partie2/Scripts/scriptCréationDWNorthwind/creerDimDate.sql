USE [DWNorthwind]
GO

-- We should create a date dimension table in the database
CREATE TABLE dbo.DimDates (
  [DateKey] int NOT NULL PRIMARY KEY IDENTITY
, [Date] datetime NOT NULL  -- valeur de type datetime stock�e dans la table
, [DateName] nVarchar(50)  -- nom du jour
, [Month] int NOT NULL -- num�ro de mois de l'ann�e
, [MonthName] nVarchar(50) NOT NULL -- nom du mois de l'ann�e
, [Quarter] int NOT NULL --le num�ro du trimestre (1,2,3 ou 4)
, [QuarterName] nVarchar(50) NOT NULL -- un nom de trimestre obtenu en concat�nant plusieurs info
, [Year] int NOT NULL -- l'ann�e num�rique
, [YearName] nVarchar(50) NOT NULL  -- info sur l'ann�e (en chaine de caract�res)
)

-- Since the date table has no associated source table we can fill the data
-- using a SQL script or wait until the ETL process. 