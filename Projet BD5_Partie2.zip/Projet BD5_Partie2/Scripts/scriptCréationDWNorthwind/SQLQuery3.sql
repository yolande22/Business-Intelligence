use DWNorthwind
go
drop table DimProducts;
drop table DimCategories;
drop table DimCustomers;
drop table DimTerritories;
drop table DimRegions;
--drop table DimDates;
