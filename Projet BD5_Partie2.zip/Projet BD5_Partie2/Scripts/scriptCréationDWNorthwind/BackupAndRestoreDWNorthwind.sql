

/************************************************ 
1) Make a copy of the empty database 
before starting the ETL process
************************************************/

BACKUP DATABASE [DWNorthwind] 
TO  DISK = 
N'C:\temp\DWNorthwind_BeforeETL.bak'
GO

/************************************************ 
2) Send the file to other team members
and tell them they can restore the database
with this code...
************************************************/

-- Check to see if they already have a copy...
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'DWNorthwind')
  BEGIN
  -- If they do, they need to close connections to the DWPubsSales database, with this code!
    ALTER DATABASE [DWNorthwind] SET SINGER_USER WITH ROLLBACK IMMEDIATE
  END

-- Now now restore the Empty database...
USE Master 
RESTORE DATABASE [DWNorthwind] 
FROM DISK = 
N'C:\temp\backups\DWNorthwind_BeforeETL.bak'
WITH REPLACE
GO