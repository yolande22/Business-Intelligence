USE [DWNorthwind]
GO

/****** Create the Fact Tables ******/




CREATE TABLE [dbo].[FactSales](
	[OrderNum] [int] NOT NULL,
	[OrderDateKey] [int] NOT NULL,
	[CustomerKey] [int] NOT NULL,
	[ProductKey] [int] NOT NULL,
	[EmployeeKey] [int] NOT NULL,
	[ShippedAddressKey] [int] NOT NULL,
	[RequiredDateKey][int] NOT NULL,
	[ShippedDateKey][int] NOT NULL,
	[ShipViaKey][int] NOT NULL,
	[ShipName] [nvarchar] (40) NOT NULL,
	[Freight][int] NULL,
	[SalesQuantity] [numeric] (10,2) NULL,
	[UnitPrice][numeric] (10,2) NULL,
	[Discount][real] NULL,
	 CONSTRAINT [PK_FactSales] PRIMARY KEY CLUSTERED ( [OrderNum], [CustomerKey],[ProductKey], [EmployeeKey], [OrderDateKey], [ShippedAddressKey],
	 [RequiredDateKey], [ShippedDateKey], [ShipViaKey] )
)
GO
